import React from 'react';
import * as bs from 'react-bootstrap'
export default function Report(props) {
  return (
    <bs.Row>
                <bs.Col md='1'></bs.Col>
                <bs.Col md='10'>
      <bs.Card.Header as="h2">Our Report</bs.Card.Header>

    </bs.Col>
    </bs.Row>
  )
}
